# app/routes/predict.py
from flask import Blueprint, render_template, request, flash
from flask_login import login_required

predict_bp = Blueprint('predict', __name__, url_prefix='/predict')

@predict_bp.route('/', methods=['GET', 'POST'])
@login_required
def predict():
    if request.method == 'POST':
        text = request.form.get('text')
        if not text:
            flash('Please enter some text to predict.')
        else:
            # Placeholder prediction logic
            prediction = "english" if "the" in text.lower() else "unknown"
            return render_template('predict/result.html', prediction=prediction, text=text)
    return render_template('predict/form.html')
